import java.util.Arrays;

public class Barney {
    public static void main(String[] args) {
        Maze maze = new Maze();
        Runner runner = new Runner();

        System.out.println(Arrays.deepToString(maze.getMaze()).replace("],", "]\n"));

        runner.go(0, 0, maze.maze);
    }
}