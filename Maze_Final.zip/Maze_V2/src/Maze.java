import java.util.Random;

public class Maze {
    public int[][] maze;

    public int[][] easyMaze() {
        int maze[][] = {{0, 1, 0, 0, 0, 0, 0, 0, 1, 0},
                        {0, 1, 0, 1, 0, 1, 1, 0, 1, 0},
                        {0, 1, 0, 1, 0, 0, 1, 0, 1, 0},
                        {0, 1, 0, 1, 0, 0, 1, 0, 1, 0},
                        {0, 1, 0, 1, 0, 0, 1, 0, 1, 0},
                        {0, 1, 0, 0, 0, 0, 1, 0, 1, 0},
                        {0, 1, 0, 1, 0, 0, 1, 0, 1, 0},
                        {0, 1, 0, 1, 1, 0, 1, 0, 1, 0},
                        {0, 1, 0, 1, 0, 1, 1, 0, 1, 0},
                        {0, 0, 0, 0, 0, 1, 1, 0, 0, 0}};
        return maze;
    }

    public Maze() {
        maze = easyMaze();
    }

    private void arrRandom() {
        Random rand = new Random();

        for (int row = 0; row < maze.length; row++) {
            for (int col = 0; col < maze[row].length; col++) {
                maze[row][col] = rand.nextInt(2) ;
            }
        }
    }

    public int[][] getMaze() {
        return maze;
    }

    public void setMaze(int[][] maze) {
        this.maze = maze;
    }
}
