import java.util.ArrayList;
import java.util.List;

public class Runner {
    private int goalX = 9;
    private int goalY = 0;
    private List<Point> hist = new ArrayList<>();
    private int x;
    private int y;

    public Runner() {
        this.x = 0;
        this.y = 0;
        hist.add(new Point());
    }

    public int getGoalX() {
        return goalX;
    }

    public void setGoalX(int goalX) {
        this.goalX = goalX;
    }

    public int getGoalY() {
        return goalY;
    }

    public void setGoalY(int goalY) {
        this.goalY = goalY;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public List<Point> getHist() {
        return hist;
    }

    public boolean checkRight(int[][] maze, int x, int y) {
        if (x < 9 && maze[y][x + 1] == 0) {
            return true;
        }
        return false;
    }

    public boolean checkUp(int[][] maze, int x, int y) {
        if (y > 0 && maze[y - 1][x] == 0) {
            return true;
        }
        return false;
    }

    public boolean checkLeft(int[][] maze, int x, int y) {
        if (x > 0 && maze[y][x - 1] == 0) {
            return true;
        }
        return false;
    }

    public boolean checkDown(int[][] maze, int x, int y) {
        if (y < 9 && maze[y + 1][x] == 0) {
            return true;
        }
        return false;
    }

    public boolean isVisited(List<Point> hist, int x, int y) {
        for (int i = 0; i < hist.size(); i++) {
            if (hist.get(i).getY() == y && hist.get(i).getX() == x) {
                return true;
            }
        }
        return false;
    }

    public boolean go(int x, int y, int[][] maze) {
        if (x == this.goalX && y == this.goalY) {
            hist.add(new Point(x, y));
            System.out.println(getHist().toString());
            return true;
        }

        hist.add(new Point(x, y));

        if (checkRight(maze, x, y) && !isVisited(hist, x + 1, y) && go(x + 1, y, maze)) {
            return true;
        } else {
            if (checkDown(maze, x, y) && !isVisited(hist, x, y + 1) && go(x, y + 1, maze)) {
                return true;
            } else {
                if (checkLeft(maze, x, y) && !isVisited(hist, x - 1, y) && go(x - 1, y, maze)) {
                    return true;
                } else {
                    if (checkUp(maze, x, y) && !isVisited(hist, x, y - 1) && go(x, y - 1, maze)) {
                        return true;
                    }
                }
            }
        }

        hist.remove(hist.size() - 1);

        return false;
    }
}